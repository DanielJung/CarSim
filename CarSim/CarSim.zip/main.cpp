// CarSim.cpp : Definiert den Einstiegspunkt f�r die Konsolenanwendung.
//

#include "stdafx.h"
#include "Car.h"
#include "CarTracker.h"
#include "Simulator.h"
#include <sstream>


int _tmain(int argc, _TCHAR* argv[])
{
	Car car(1100.0, 0.287, 0.02, 2.0, 2.87, 0.27);
	CarTracker tracker;
	Simulator sim(car, 0.0, 60.0, 0.001);

	try{
		sim.StartSim(tracker);
	}
	catch (string s){
		cout << "Exception. " << s << endl;
	}
	system("pause");
	return 0;
}

