#include "stdafx.h"
#include "ShiftControl.h"


ShiftControl::ShiftControl(const Car& oCar) : moCar(oCar)
{
}


ShiftControl::~ShiftControl()
{
}

unsigned int ShiftControl::onShift() {
	if (moCar.getMotor().getFrequency() > 2500.0 / 60.0 && moCar.getGearbox().getCurrentGear() < 5){
		return moCar.getGearbox().getCurrentGear() + 1;
	}
	return moCar.getGearbox().getCurrentGear();
}