#pragma once

#include "Car.h"
#include "CarTracker.h"

class Simulator
{
public:
	Simulator(Car& oCar, double tBegin, double tEnd, double dt);
	~Simulator();

	void StartSim(CarTracker& oCarTracker);
private:
	Car& moCar;
	double mdTime;
	double mdDT;
	unsigned int miNumSteps;
};

