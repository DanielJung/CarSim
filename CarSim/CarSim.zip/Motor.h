#pragma once
class Motor
{
public:
	Motor(double dMinFrequency, double dMaxFrequency);
	~Motor();

	void setFrequency(double dFrequency);
	double getFrequency() const;

	double getTorque() const;

	double getMinFrequency() const;
	double getMaxFrequency() const;
private:
	double mdFrequency;

	double mdMinFrequency;
	double mdMaxFrequency;
};

