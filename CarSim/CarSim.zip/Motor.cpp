#include "stdafx.h"
#include "Motor.h"

#define A0 -0.033640557453369
#define A1 3.721828048006285
#define A2 7.963813900057554


Motor::Motor(double dMinFrequency, double dMaxFrequency) : 
mdFrequency(dMinFrequency),
mdMinFrequency(dMinFrequency),
mdMaxFrequency(dMaxFrequency)
{
	cout << "Starting Motor. Min: " << mdMinFrequency << " | Max: " << mdMaxFrequency << endl;
}


Motor::~Motor()
{
}

void Motor::setFrequency(double dFrequency){
	if (dFrequency > mdMaxFrequency){
		throw string("Your motor caught fire cause of too high frequency");
	}
	else if (dFrequency < mdMinFrequency){
		throw string("Your motor ran out cause of too low frequency");
	}
	mdFrequency = dFrequency;
}

double Motor::getFrequency() const {
	return mdFrequency;
}

double Motor::getTorque() const {
	return (A0*mdFrequency*mdFrequency + A1*mdFrequency + A2)+20.0;
}

double Motor::getMinFrequency() const {
	return mdMinFrequency;
}

double Motor::getMaxFrequency() const {
	return mdMaxFrequency;
}